package com.company;

import java.awt.*;

import static java.lang.Math.random;

public class Kula {
    public int x, y, sizev,sizeh,size, xspeed, yspeed;
    public Color kolor;
    private final int MAX_SPEED = 10;
    Panel p;

    public Kula(int x, int y, int size, Panel panel) {
        this.x = x;
        this.y = y;
        this.sizev = size;
        this.sizeh = size;
        this.size = size;
        this.p = panel;

        kolor = new Color((float) random(), (float) random(), (float) random());

        do {
            xspeed = (int) (random() * MAX_SPEED * 2 - MAX_SPEED);
            yspeed = (int) (random() * MAX_SPEED * 2 - MAX_SPEED);
        } while (xspeed == 0 || yspeed == 0);

    }

    public void update() {


        if (x - (size / 2) <= 0 || x + (size / 2) >= p.getWidth()) {

            xspeed = -xspeed;
        }

        if (y - (size / 2) <= 0 || y + (size / 2) >= p.getHeight())
            yspeed = -yspeed;

        //kolizje
        x += xspeed;
        y += yspeed;

        /// if(sizev<size)
        //  sizev++;
        //  else if(sizeh<size)
        //  sizeh++;
    }




}
