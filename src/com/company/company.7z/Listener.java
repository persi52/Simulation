package com.company;

import java.awt.event.*;
import static java.lang.Math.*;
import static java.lang.Math.pow;

public class Listener implements MouseListener, ActionListener, MouseMotionListener, MouseWheelListener {

    Panel p;

    public Listener(Panel panel){
        this.p = panel;
    }

    @Override
    public void mouseClicked(MouseEvent mouseEvent) {



    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {
        Kula k = new Kula(mouseEvent.getX(), mouseEvent.getY(), p.size,p);

        //System.out.println(p.isSpaceEmpty(k));

        if (p.isSpaceEmpty(k)) {
            p.listaKul.add(k);
        }

        p.repaint();


    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {
        p.isEntered = true;
    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {
        p.isEntered = false;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (p.isEntered) {


            for (Kula k : p.listaKul) {


                k.update();


                for (int i = 0; i < p.listaKul.size(); i++) {

                    if (k != p.listaKul.get(i)) {
                        double distX, distY, dist;


                        distX = abs(k.x - p.listaKul.get(i).x);
                        distY = abs(k.y - p.listaKul.get(i).y);
                        dist = sqrt(pow(distX, 2) + pow(distY, 2));


                        if (dist <= ((p.listaKul.get(i).size) / 2.0 + k.size / 2.0)) {


                            //  if(k.sizev==k.size && k.sizeh==k.size) {
                            //  if(k.y != listaKul.get(i).y)
                            // else if(k.x != listaKul.get(i).x)
                            //      k.sizev -= k.sizev/ sqrt((k.xspeed*k.xspeed)+(k.yspeed*k.yspeed));

                            int newSpeedX1 = (p.listaKul.get(i).xspeed * (p.listaKul.get(i).size - k.size) + (2 * p.listaKul.get(i).size * k.xspeed)) / (p.listaKul.get(i).size + k.size);
                            int newSpeedY1 = (p.listaKul.get(i).yspeed * (p.listaKul.get(i).size - k.size) + (2 * p.listaKul.get(i).size * k.yspeed)) / (p.listaKul.get(i).size + k.size);
                            int newSpeedX2 = (k.xspeed * (k.size - p.listaKul.get(i).size) + (2 * k.size * p.listaKul.get(i).xspeed)) / (p.listaKul.get(i).size + k.size);
                            int newSpeedY2 = (k.yspeed * (k.size - p.listaKul.get(i).size) + (2 * k.size * p.listaKul.get(i).yspeed)) / (p.listaKul.get(i).size + k.size);

                            p.listaKul.get(i).xspeed = newSpeedX1;

                            p.listaKul.get(i).yspeed = newSpeedY1;

                            k.xspeed = newSpeedX2;

                            k.yspeed = newSpeedY2;


                        }
                    }


                }


            }


        }

        p.repaint();
    }


    @Override
    public void mouseDragged(MouseEvent mouseEvent) {

        //       listaKul.add(new Kula(mouseEvent.getX(), mouseEvent.getY(), size));
        // repaint();
        Kula k = new Kula(mouseEvent.getX(), mouseEvent.getY(), p.size,p);

        //System.out.println(p.isSpaceEmpty(k));

        if (p.isSpaceEmpty(k)) {
            p.listaKul.add(k);
        }

        p.repaint();

    }

    @Override
    public void mouseMoved(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent mouseEvent) {

        if (mouseEvent.getWheelRotation() < 0) p.size += 3;
        else p.size -= 3;


    }
}